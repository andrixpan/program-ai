#!/usr/bin/env bash
source venv/bin/activate
