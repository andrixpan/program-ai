from setup_tools.magicinstaller.requirement import SimpleRequirement


class AudioToNumpy(SimpleRequirement):
    package_name = 'audio2numpy'
