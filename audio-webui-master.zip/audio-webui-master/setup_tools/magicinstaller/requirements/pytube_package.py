from setup_tools.magicinstaller.requirement import SimpleRequirement


class PyTube(SimpleRequirement):
    package_name = 'pytube'
