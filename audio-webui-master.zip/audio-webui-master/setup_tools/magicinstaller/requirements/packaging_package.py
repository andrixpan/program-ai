from setup_tools.magicinstaller.requirement import SimpleRequirement


class Packaging(SimpleRequirement):
    package_name = 'packaging'
