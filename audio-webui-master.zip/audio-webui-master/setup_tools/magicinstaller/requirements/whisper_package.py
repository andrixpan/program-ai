from setup_tools.magicinstaller.requirement import SimpleRequirement


class Whisper(SimpleRequirement):
    package_name = 'openai-whisper'
