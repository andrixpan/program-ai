## 📚 readme pages 📚
* ❗ [Common issues](common_issues.md)
* 🐶 Bark
  * ❓ [How Bark works](bark/how_bark_works.md)
* 😎 RVC
  * 🏃‍ [Rvc Training](rvc/training.md)

## 🖥️ For developers 🖥️
* [Extensions](extensions/index.md)