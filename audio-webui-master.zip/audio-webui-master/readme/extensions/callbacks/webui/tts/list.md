# webui.tts.list callback

### Description
Add new Text to speech modules to the selection list on the Text to speech tab.  
Return `TTSModelLoader` objects in this callback, supports `TTSModelLoader` and `list[TTSModelLoader]` as return types.

### More
More info about `TTSModelLoader` in `webui.modules.implementations.ttsmodels`.