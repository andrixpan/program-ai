# Guidelines for extensions

## Do:
* Use callbacks

## Don't:
* Monkeypatch, instead, create a PR or request the feature.
