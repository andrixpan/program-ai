<h1 class="center-h">❗ Info ❗</h1>
<h2 class='center-h'>🧾 Credits (Not including libraries of libraries, no particular order)</h2>

|                                                                                                         Project | Creator                                                 |
|----------------------------------------------------------------------------------------------------------------:|---------------------------------------------------------|
|                                                           [Audio-Webui](https://github.com/gitmylo/audio-webui) | [gitmylo](https://github.com/gitmylo/audio-webui)       |
|                            [Bark voice cloning](https://github.com/gitmylo/bark-voice-cloning-HuBERT-quantizer) | [gitmylo](https://github.com/gitmylo)                   |
|                                                                         [Bark](https://github.com/suno-ai/bark) | [suno-ai](https://github.com/suno-ai)                   |
|                                                            [Demucs](https://github.com/facebookresearch/demucs) | [facebookresearch](https://github.com/facebookresearch) |
|                                                    [AudioCraft](https://github.com/facebookresearch/audiocraft) | [facebookresearch](https://github.com/facebookresearch) |
| [RVC (Retrieval based voice conversion)](https://github.com/RVC-Project/Retrieval-based-Voice-Conversion-WebUI) | [RVC-Project](https://github.com/RVC-Project)           |
|                                                                    [Whisper](https://github.com/openai/whisper) | [OpenAI](https://github.com/openai)                     |
|                                                                [AudioLDM](https://github.com/haoheliu/AudioLDM) | [CVSSP](https://huggingface.co/cvssp)                   |
|                                                          [Noisereduce](https://github.com/timsainb/noisereduce) | [timsainb](https://github.com/timsainb/noisereduce)     |
