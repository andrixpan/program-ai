#!/usr/bin/env bash

git pull
read -n1 -r -p "Press any key to exit..." key
