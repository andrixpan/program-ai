# Contributing
You can contribute code changes by making a [pull request](https://github.com/gitmylo/audio-webui/pulls)

You can also request new features or report bugs by making an [issue](https://github.com/gitmylo/audio-webui/issues)
